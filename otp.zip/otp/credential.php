<?php 
	/*Enter your API_KEY*/
	define("API_KEY", 'dlUTAyWJGTQ-t7s90VhC0igqgdrNFrV5XxsLIVbNH2');

	/*You can enter mobile number here*/
	define("MOBILE", '');
 ?>