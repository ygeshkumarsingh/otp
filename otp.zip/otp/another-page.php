<?php 
echo "hiiiiii priyog educational";
?>