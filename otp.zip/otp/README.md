# send-mobile-otp-php
Sending OTP SMS in PHP from localhost using textlocal  
Follow the tutorial At: https://youtu.be/90fNE_S46do
